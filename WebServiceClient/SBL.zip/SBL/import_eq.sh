#!/bin/bash
for ((i = 1; i < 9 ; i++)) ; do
    echo "Importing earthquakes with magnitude $i to chp03.earthquakes PostGIS table..."
    ogr2ogr -append -f PostgreSQL -nln earthquakes PG:"dbname='pruebagps' user='postgres' password='davidpedro24'" 2012_Earthquakes_ALL.kml -sql "SELECT name, description, CAST($i AS integer) AS magnitude FROM \"Magnitude $i\""
done
